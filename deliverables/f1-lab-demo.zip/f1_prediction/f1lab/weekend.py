"""Dự đoán riêng từng phiên từ lịch sử trước cuối tuần, không dùng Q hiện tại."""
from __future__ import annotations

import hashlib
import json
import uuid
from datetime import timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed

import fastf1
import joblib
import numpy as np
import pandas as pd
from sqlalchemy import delete, text
from sqlalchemy.orm import Session
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LinearRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

from .config import AppConfig
from .db import (Driver, Team, WeekendSession, WeekendResult, WeekendRun,
                 WeekendPrediction, utcnow)
from .ingest import FastF1DataSource
from .ml import RaceEvaluator
from .models import RaceModel
from .repositories import ResultRepository

KINDS = {"Practice 1": "FP1", "Practice 2": "FP2", "Practice 3": "FP3",
         "Qualifying": "Q", "Sprint": "S", "Sprint Qualifying": "SQ", "Sprint Shootout": "SQ", "Race": "R"}
LABELS = {"FP1": "FP1", "FP2": "FP2", "FP3": "FP3", "Q": "Qualifying", "SQ": "Sprint Qualifying", "S": "Sprint", "R": "Race"}
NUMERIC = ["driver_session_form", "team_session_form", "driver_race_form", "team_race_form",
           "circuit_session_form", "session_history_count", "race_history_count", "season_round", "field_size"]
CATEGORICAL = ["team_id", "circuit_id"]
FEATURES = NUMERIC + CATEGORICAL
VERSION = "preweekend-v1"


def utc_timestamp(value):
    stamp = pd.Timestamp(value)
    return stamp.tz_convert("UTC").tz_localize(None) if stamp.tzinfo else stamp


class WeekendRepository:
    def __init__(self, db):
        self.db = db

    def sessions(self):
        with self.db.connect() as conn:
            return pd.read_sql(text("""SELECT s.*, r.season, r.`round` AS season_round,
                r.name AS race_name, r.circuit_id FROM weekend_sessions s
                JOIN races r ON r.id=s.race_id ORDER BY s.start_utc"""), conn,
                parse_dates=["start_utc", "cutoff_utc", "history_after_utc"])

    def results(self):
        with self.db.connect() as conn:
            return pd.read_sql(text("""SELECT z.*, s.kind, s.race_id, s.start_utc,
                s.cutoff_utc, s.history_after_utc, r.season, r.`round` AS season_round,
                r.circuit_id, r.name AS race_name, d.name AS driver_name, t.name AS team_name
                FROM weekend_results z JOIN weekend_sessions s ON z.session_id=s.id
                JOIN races r ON r.id=s.race_id JOIN drivers d ON d.id=z.driver_id
                JOIN teams t ON t.id=z.team_id ORDER BY s.start_utc, z.driver_id"""), conn,
                parse_dates=["start_utc", "cutoff_utc", "history_after_utc"])

    def save_session(self, values, rows=None):
        with Session(self.db) as session, session.begin():
            session.merge(WeekendSession(**values))
            session.flush()
            if rows is not None:
                session.execute(delete(WeekendResult).where(WeekendResult.session_id == values["id"]))
                for row in rows:
                    session.merge(Driver(id=row["driver_id"], name=row["driver_name"]))
                    session.merge(Team(id=row["team_id"], name=row["team_name"]))
                session.flush()
                for row in rows:
                    session.add(WeekendResult(session_id=values["id"], **{k: row.get(k) for k in
                                ("driver_id", "team_id", "position", "best_seconds")}))

    def save_prediction(self, target, output, bundle, artifact):
        run_id = str(uuid.uuid4())
        with Session(self.db) as session, session.begin():
            session.add(WeekendRun(id=run_id, session_id=target.id,
                cutoff_utc=target.cutoff_utc.to_pydatetime(), model=bundle["name"], artifact=str(artifact),
                details={"version": VERSION, "mode": "preweekend", "retrospective_roster": True,
                         "train_through": str(bundle["train_through"]), "roster_source": output.roster_source.iloc[0]}))
            session.flush()
            for row in output.to_dict("records"):
                session.add(WeekendPrediction(run_id=run_id, driver_id=row["driver_id"], score=float(row["score"]),
                    rank=int(row["predicted_rank"]), actual_rank=int(row["label"]) if pd.notna(row["label"]) else None,
                    features={k: None if pd.isna(row[k]) else row[k] for k in FEATURES}))
        return run_id


class WeekendCollector:
    def __init__(self, db, config=None, api=fastf1):
        self.config = config or AppConfig()
        self.repository = WeekendRepository(db)
        self.core_results = ResultRepository(db)
        self.api = api

    def collect(self, years, kinds=None, rounds=None, refresh=False, schedule_only=False):
        FastF1DataSource(self.config).setup_cache()
        existing = self.repository.sessions()
        done = set(existing.loc[existing.status == "ready", "id"]) if not existing.empty else set()
        report, jobs = [], []
        for year in years:
            schedule = self.api.get_event_schedule(year, include_testing=False)
            source_file = self.config.raw_dir / str(year) / "weekend_schedule.csv"
            source_file.parent.mkdir(parents=True, exist_ok=True)
            schedule.to_csv(source_file, index=False)
            q_r = {kind: self.core_results.read(kind) for kind in ("Q", "R")}
            for _, event in schedule.iterrows():
                number = int(event.RoundNumber)
                if rounds and number not in rounds:
                    continue
                rid = year * 100 + number
                starts = [utc_timestamp(event[f"Session{i}DateUtc"]) for i in range(1, 6)
                          if pd.notna(event.get(f"Session{i}DateUtc"))]
                if not starts:
                    continue
                cutoff = min(starts) - timedelta(seconds=1)
                for i in range(1, 6):
                    kind = KINDS.get(event.get(f"Session{i}"))
                    if not kind or (kinds and kind not in kinds) or pd.isna(event.get(f"Session{i}DateUtc")):
                        continue
                    sid = f"{rid}-{kind}"
                    if sid in done and not refresh and not schedule_only:
                        continue
                    start = utc_timestamp(event[f"Session{i}DateUtc"])
                    values = dict(id=sid, race_id=rid, kind=kind, start_utc=start.to_pydatetime(),
                        cutoff_utc=cutoff.to_pydatetime(), history_after_utc=(start + timedelta(hours=6)).to_pydatetime(),
                        collected_at=utcnow(), source="FastF1 schedule and timing / Jolpica", details={},
                        status="not_collected" if start.to_pydatetime() + timedelta(hours=6) < utcnow() else "scheduled")
                    if schedule_only:
                        previous = existing[existing.id == sid]
                        if not previous.empty:
                            if previous.status.iloc[0] != "scheduled" or values["status"] != "not_collected":
                                values["status"] = previous.status.iloc[0]
                            values["collected_at"] = pd.Timestamp(previous.collected_at.iloc[0]).to_pydatetime()
                            details = previous.details.iloc[0]
                            values["details"] = json.loads(details) if isinstance(details, str) else details
                        self.repository.save_session(values)
                        report.append({"session": sid, "status": values["status"]})
                        continue
                    known = q_r[kind][q_r[kind].race_id == rid] if kind in q_r else None
                    jobs.append((values, year, number, kind, known))
        # Network reads độc lập; ghi MySQL tuần tự ở thread điều phối.
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(self.collect_one, *job) for job in jobs]
            for future in as_completed(futures):
                values, rows = future.result()
                self.repository.save_session(values, rows)
                report.append({"session": values["id"], "status": values["status"], **values["details"]})
                print(report[-1], flush=True)
        path = self.config.processed_dir / "weekend_collection.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(report, indent=2, ensure_ascii=False))
        return report

    def collect_one(self, values, year, number, kind, known):
        rows = None
        try:
            if values["start_utc"] + timedelta(hours=6) < utcnow():
                if known is not None:
                    if known.empty:
                        raise ValueError("Chưa có kết quả phiên trong nguồn Q/R")
                    rows = known.rename(columns={"q1_seconds": "best_seconds"}).to_dict("records")
                    for row in rows:
                        row["position"] = int(row["position"]) if pd.notna(row["position"]) else None
                        row["best_seconds"] = float(row["best_seconds"]) if pd.notna(row["best_seconds"]) else None
                else:
                    session = self.api.get_session(year, number, kind)
                    session.load(laps=True, telemetry=False, weather=False, messages=True)
                    identities = None
                    invalid = session.results.DriverId.astype(str).str.lower().isin(["nan", "none", "", "<na>"])
                    if invalid.any():
                        official = self.api.get_session(year, number, "Q")
                        official.load(laps=False, telemetry=False, weather=False, messages=False)
                        identities = official.results
                    rows = self.normalize(session, kind, identities)
                if not rows or not any(row["position"] is not None for row in rows):
                    rows = None
                    raise ValueError("Không có kết quả hợp lệ")
                values["status"] = "ready" if all(row["position"] is not None for row in rows) else "partial"
                values["details"] = {"rows": len(rows), "label_definition": "fastest_valid_lap" if kind.startswith("FP") else "session_classification"}
                folder = self.config.raw_dir / str(year) / f"round_{number:02d}" / kind
                folder.mkdir(parents=True, exist_ok=True)
                pd.DataFrame(rows).to_csv(folder / "weekend_results.csv", index=False)
        except Exception as exc:
            rows = None
            values["status"] = "unavailable"
            values["details"] = {"error": str(exc)[:500]}
        return values, rows

    @staticmethod
    def normalize(session, kind, identities=None):
        results = session.results.copy()
        best = {}
        if kind.startswith("FP"):
            laps = session.laps
            # Deleted laps không được dùng. Nếu nguồn thiếu cờ, không khẳng định vòng hợp lệ.
            if "Deleted" not in laps or laps.Deleted.dtype != bool:
                raise ValueError("Nguồn FP thiếu cờ Deleted")
            laps = laps[(laps.Deleted == False) & laps.LapTime.notna() & (laps.LapTime.dt.total_seconds() > 0)]  # noqa: E712
            best = laps.groupby("DriverNumber").LapTime.min().dt.total_seconds().to_dict()
            ordered = sorted(best, key=lambda number: (best[number], str(number)))
            positions = {str(number): i + 1 for i, number in enumerate(ordered)}
        else:
            positions = {}
        rows = []
        for _, row in results.iterrows():
            driver_id, team_id = str(row.get("DriverId", "")), str(row.get("TeamId", ""))
            missing = {"nan", "none", "", "<na>"}
            if driver_id.lower() in missing:
                match = identities[identities.Abbreviation == row.Abbreviation] if identities is not None else pd.DataFrame()
                if len(match) == 1 and str(match.DriverId.iloc[0]).lower() not in missing:
                    driver_id, team_id = str(match.DriverId.iloc[0]), str(match.TeamId.iloc[0])
                else:
                    # Tay đua dự bị FP không có Ergast ID: giữ định danh nguồn riêng, không gán cho người ngồi cùng xe.
                    name = str(row.FullName)
                    if name.lower() in missing or str(row.Abbreviation).lower() in missing:
                        raise ValueError("Thiếu định danh tay đua trong live timing")
                    driver_id = "live-" + hashlib.sha256(name.encode()).hexdigest()[:20]
            if team_id.lower() in missing:
                matches = identities[identities.TeamName == row.TeamName] if identities is not None else pd.DataFrame()
                if not matches.empty and str(matches.TeamId.iloc[0]).lower() not in missing:
                    team_id = str(matches.TeamId.iloc[0])
                elif str(row.TeamName).lower() not in missing:
                    team_id = "live-team-" + hashlib.sha256(str(row.TeamName).encode()).hexdigest()[:16]
                else:
                    raise ValueError("Thiếu định danh đội trong live timing")
            position = positions.get(str(row.DriverNumber)) if kind.startswith("FP") else row.Position
            position = int(position) if pd.notna(position) and float(position) > 0 else None
            rows.append(dict(driver_id=driver_id, driver_name=str(row.FullName), team_id=team_id,
                             team_name=str(row.TeamName), position=position, best_seconds=best.get(str(row.DriverNumber))))
        return rows


class WeekendFeatureBuilder:
    """Đầu vào chỉ gồm lịch sử kết thúc trước cutoff của phiên đầu cuối tuần."""
    def build_target(self, target, history, roster):
        if roster.empty or roster.driver_id.duplicated().any():
            raise ValueError("Danh sách tay đua thiếu hoặc trùng")
        sizes = history.groupby("session_id").driver_id.transform("size")
        history = history.assign(relative_rank=(history.position - 1) / (sizes - 1).clip(lower=1))
        past = history[(history.history_after_utc < target.cutoff_utc) & history.position.notna()].sort_values("start_utc")
        labels = roster.set_index("driver_id").position if "position" in roster else pd.Series(dtype=float)
        eligible = len(labels) == len(roster) and set(labels.dropna()) == set(range(1, len(roster) + 1))
        rows = []
        for item in roster.itertuples():
            same = past[past.kind == target.kind]
            race = past[past.kind == "R"]
            driver = same[same.driver_id == item.driver_id]
            team = same[same.team_id == item.team_id].groupby("session_id", sort=False).relative_rank.mean()
            race_driver = race[race.driver_id == item.driver_id]
            race_team = race[race.team_id == item.team_id].groupby("session_id", sort=False).relative_rank.mean()
            circuit = driver[driver.circuit_id == target.circuit_id]
            rows.append(dict(race_id=int(target.race_id), session_id=target.id, kind=target.kind,
                season=int(target.season), season_round=int(target.season_round), race_name=target.race_name,
                cutoff_utc=target.cutoff_utc, start_utc=target.start_utc, driver_id=item.driver_id,
                driver_name=item.driver_name, team_id=item.team_id, team_name=item.team_name,
                circuit_id=target.circuit_id, field_size=len(roster), label=labels.get(item.driver_id, np.nan),
                eligible=eligible, quali_position=0.0,  # phá hòa bằng ID, tuyệt đối không Q hiện tại
                driver_session_form=driver.relative_rank.tail(5).mean() if len(driver) else np.nan,
                team_session_form=team.tail(5).mean(), driver_race_form=race_driver.relative_rank.tail(5).mean() if len(race_driver) else np.nan,
                team_race_form=race_team.tail(5).mean(), circuit_session_form=circuit.relative_rank.mean() if len(circuit) else np.nan,
                session_history_count=len(driver), race_history_count=len(race_driver)))
        return pd.DataFrame(rows)

    def build(self, sessions, results):
        frames = []
        for target in sessions.itertuples():
            roster = results[results.session_id == target.id]
            if not roster.empty:
                frames.append(self.build_target(target, results, roster))
        if not frames:
            raise ValueError("Chưa có kết quả phiên; chạy weekend-data")
        return pd.concat(frames, ignore_index=True)


class WeekendFormModel(RaceModel):
    name = "Baseline lịch sử phiên"

    def fit(self, frame):
        return self

    def predict(self, frame):
        return frame.driver_session_form.fillna(frame.driver_race_form).fillna(0.5).to_numpy(float)


class WeekendRegressionModel(RaceModel):
    def __init__(self, name):
        self.name = name
        estimators = {"Linear Regression": LinearRegression(),
            "Random Forest": RandomForestRegressor(n_estimators=100, max_depth=7, min_samples_leaf=4, random_state=42, n_jobs=2),
            "HistGradientBoosting": HistGradientBoostingRegressor(max_iter=100, max_leaf_nodes=12, early_stopping=False, random_state=42)}
        self.estimator = Pipeline([("preprocess", ColumnTransformer([
            ("numeric", Pipeline([("impute", SimpleImputer(strategy="median", add_indicator=True, keep_empty_features=True)),
                                   ("scale", StandardScaler())]), NUMERIC),
            ("category", OneHotEncoder(handle_unknown="ignore", sparse_output=False), CATEGORICAL)])),
            ("model", estimators[name])])

    def fit(self, frame):
        self.estimator.fit(frame[FEATURES], (frame.label - 1) / (frame.field_size - 1).clip(lower=1))
        return self

    def predict(self, frame):
        return self.estimator.predict(frame[FEATURES])


class WeekendTrainer:
    names = ("Baseline lịch sử phiên", "Linear Regression", "Random Forest", "HistGradientBoosting")

    def __init__(self, db, config=None):
        self.config = config or AppConfig()
        self.repository = WeekendRepository(db)
        self.builder = WeekendFeatureBuilder()

    def train(self, test_year=2026):
        frame = self.builder.build(self.repository.sessions(), self.repository.results())
        experiment = utcnow().strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:6]
        folder = self.config.artifacts_dir / "weekend" / experiment
        folder.mkdir(parents=True)
        frame.to_csv(folder / "features.csv", index=False)
        summaries, metrics, predictions = {}, [], []
        for kind in LABELS:
            data = frame[(frame.kind == kind) & frame.eligible]
            train = data[data.season < test_year - 1]
            valid = data[data.season == test_year - 1]
            test = data[data.season == test_year]
            if train.race_id.nunique() < 3 or valid.race_id.nunique() < 2:
                summaries[kind] = {"status": "insufficient_data", "train_sessions": int(train.race_id.nunique()), "validation_sessions": int(valid.race_id.nunique())}
                continue
            board = []
            for name in self.names:
                model = WeekendFormModel() if name == self.names[0] else WeekendRegressionModel(name)
                model.fit(train)
                output = RaceEvaluator().rank(valid, model.predict(valid))
                # Điểm là tỷ lệ vị trí, metric raw đổi về đơn vị hạng trước khi đánh giá.
                output["score"] = 1 + output.score * (output.field_size - 1)
                metric, _ = RaceEvaluator().evaluate(output)
                board.append({"model": name, **metric})
                metrics.append(dict(kind=kind, split="validation", model=name, **metric))
            board.sort(key=lambda x: (x["mae_rank"], -x["spearman"], x["model"]))
            name = board[0]["model"]
            selection = {"kind": kind, "selected": name, "validation": board, "frozen_before_test": True}
            (folder / f"{kind}-selection.json").write_text(json.dumps(selection, indent=2))
            final_train = data[data.season < test_year]
            model = WeekendFormModel() if name == self.names[0] else WeekendRegressionModel(name)
            model.fit(final_train)
            artifact = folder / f"{kind}.joblib"
            bundle = {"model": model, "name": name, "kind": kind, "features": FEATURES, "version": VERSION,
                      "train_through": final_train.start_utc.max(), "test_year": test_year,
                      "data_sha256": hashlib.sha256(frame.to_csv(index=False).encode()).hexdigest()}
            joblib.dump(bundle, artifact)
            summaries[kind] = {"status": "ready", "selected": name, "artifact": str(artifact.relative_to(self.config.root)),
                               "train_sessions": int(final_train.race_id.nunique()), "validation_sessions": int(valid.race_id.nunique())}
            if not test.empty:
                output = RaceEvaluator().rank(test, model.predict(test))
                output["score"] = 1 + output.score * (output.field_size - 1)
                metric, _ = RaceEvaluator().evaluate(output)
                metrics.append(dict(kind=kind, split="test", model=name, **metric))
                output["model"] = name
                predictions.append(output)
                summaries[kind]["test_sessions"] = int(test.race_id.nunique())
            print(kind, summaries[kind], flush=True)
        pd.DataFrame(metrics).to_csv(folder / "metrics.csv", index=False)
        if predictions:
            pd.concat(predictions).to_csv(folder / "predictions.csv", index=False)
        summary = {"experiment": experiment, "created_at": utcnow().isoformat(), "sessions": summaries,
                   "mode": "preweekend", "test_year": test_year, "validation_year": test_year - 1,
                   "limitations": "Retrospective participant lists and revised sources; no historical publication snapshots; FP fastest lap is not race pace; 2026 is exploratory after previous test exposure."}
        temp = self.config.artifacts_dir / "weekend" / "latest.tmp"
        temp.write_text(json.dumps(summary, indent=2, ensure_ascii=False))
        temp.replace(temp.with_suffix(".json"))
        return summary


class WeekendPredictionService:
    def __init__(self, db, config=None):
        self.config = config or AppConfig()
        self.repository = WeekendRepository(db)

    def predict(self, session_id):
        sessions = self.repository.sessions()
        target_rows = sessions[sessions.id == session_id]
        if target_rows.empty:
            raise ValueError("Phiên này không có trong lịch của chặng")
        target = next(target_rows.itertuples())
        summary_path = self.config.artifacts_dir / "weekend" / "latest.json"
        if not summary_path.exists():
            raise ValueError("Cần huấn luyện mô hình từng phiên trước")
        summary = json.loads(summary_path.read_text())
        info = summary["sessions"].get(target.kind, {})
        if info.get("status") != "ready":
            raise ValueError("Chưa đủ dữ liệu lịch sử để huấn luyện phiên này")
        artifact = self.config.root / info["artifact"]
        bundle = joblib.load(artifact)
        if bundle["version"] != VERSION or bundle["features"] != FEATURES:
            raise ValueError("Phiên bản mô hình không tương thích")
        if not bundle["train_through"] < target.cutoff_utc:
            raise ValueError("Mô hình đã học sau cutoff; chỉ demo các mùa sau training")
        history = self.repository.results()
        roster = history[history.session_id == session_id]
        roster_source = "Danh sách tham gia phiên từ nguồn hồi cứu"
        if roster.empty:
            # Chưa có roster phiên: chỉ dùng danh sách phiên R gần nhất trước cutoff.
            candidates = history[(history.kind == "R") & (history.history_after_utc < target.cutoff_utc)]
            if candidates.empty:
                raise ValueError("Chưa có danh sách tay đua để dự đoán")
            roster = candidates[candidates.session_id == candidates.sort_values("start_utc").session_id.iloc[-1]].copy()
            roster["position"] = np.nan
            roster_source = "Tạm dùng danh sách Race gần nhất trước cutoff; cần xác nhận thay đổi tay đua/đội"
        frame = WeekendFeatureBuilder().build_target(target, history, roster)
        output = RaceEvaluator().rank(frame, bundle["model"].predict(frame))
        output["score"] = 1 + output.score * (output.field_size - 1)
        output["roster_source"] = roster_source
        output["run_id"] = self.repository.save_prediction(target, output, bundle, artifact.relative_to(self.config.root))
        return output
